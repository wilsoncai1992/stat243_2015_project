/* Copyright (c) 2000-2015 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct MROU_RECTANGLE *_unur_mrou_rectangle_new( void );
int _unur_mrou_rectangle_compute( struct MROU_RECTANGLE *rr );
