/* Copyright (c) 2000-2015 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

void *_unur_xmalloc(size_t size)             ATTRIBUTE__MALLOC;
void *_unur_xrealloc(void *ptr, size_t size) ATTRIBUTE__MALLOC;
