/* Copyright (c) 2000-2015 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct unur_hri_par { 
  double p0;                          
};
struct unur_hri_gen { 
  double p0;                          
  double left_border;                 
  double hrp0;                        
};
