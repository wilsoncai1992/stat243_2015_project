/* Copyright (c) 2000-2015 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct unur_mvstd_par { 
  int dummy;              
};
struct unur_mvstd_gen { 
  const char *sample_routine_name; 
};
