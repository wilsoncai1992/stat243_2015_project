/* Copyright (c) 2000-2015 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct unur_hrd_par { 
  int dummy;
};
struct unur_hrd_gen { 
  double upper_bound;                 
  double left_border;                 
};
