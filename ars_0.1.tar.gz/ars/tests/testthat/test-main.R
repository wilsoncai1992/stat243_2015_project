library(foreach)
library(doParallel)
registerDoParallel(4)


#Normal Distribution
#--------------------------
testiter <- foreach(it = 1:100, .combine = rbind) %dopar% {
  h <- function(x){
    return(log(dnorm(x, 0, 1)))
  }
  normtest <- ars243(n = 1000, h = h, k = 10)
  normcheck <- rnorm(1000, 0, 1)
  pvalsnorm <- ks.test(normtest, normcheck)$p.value
  return(pvalsnorm)
}
if (mean(testiter<0.05) < 0.1){
  print("The test of the Normal Distribution passes.")
}else{
  print("The test of the Normal Distribution fails.")
}
#--------------------------


#Beta Distribution
#--------------------------
testiter <- foreach(it = 1:100, .combine = rbind) %dopar% {
  h <- function(x){
    return(log(dbeta(x, 3, 2)))
  }
  betatest <- ars243(n = 1000, h = h, k = 10, domain = c(0,1))
  betacheck <- rbeta(1000, 3, 2)
  pvalsbeta <- ks.test(betatest, betacheck)$p.value
  return(pvalsbeta)
}
if (mean(testiter<0.05) < 0.1){
 print("The test of the Beta Distribution passes.")
}else{
  print("The test of the Beta Distribution fails.")
}
#--------------------------


#Chi Square Distribution
#--------------------------
testiter <- foreach(it = 1:100, .combine = rbind) %dopar% {
  h <- function(x){
    return(log(dchisq(x, 3)))
  }
  chisqtest <- ars243(n = 1000, h = h, k = 10, domain = c(0,15))
  chisqcheck <- rchisq(1000, 3)
  pvalschisq <- ks.test(chisqtest, chisqcheck)$p.value
  return(pvalschisq)
}
if (mean(testiter<0.05) < 0.1){
  print("The test of the Chi Square Distribution passes.")
}else{
  print("The test of the Chi Square Distribution fails.")
}
#--------------------------


#Exponential Distribution
#--------------------------
testiter <- foreach(it = 1:100, .combine = rbind) %dopar% {
  h <- function(x){
    return(log(dexp(x, 1)))
  }
  exptest <- ars243(n = 1000, h = h, k = 10, domain = c(0,5))
  expcheck <- rexp(1000, 1)
  pvalsexp <- ks.test(exptest, expcheck)$p.value
  return(pvalsexp)
}
if (mean(testiter<0.05) < 0.1){
  print("The test of the Exponential Distribution passes.")
}else{
  print("The test of the Exponential Distribution fails.")
}
#--------------------------

#Uniform Distribution
#--------------------------
testiter <- foreach(it = 1:100, .combine = rbind) %dopar% {
  h <- function(x){
    return(log(dunif(x, 0, 1)))
  }
  uniftest <- ars243(n = 1000, h = h, k = 5, domain = c(0, 1))
  unifcheck <- runif(1000, 0, 1)
  pvalsunif <- ks.test(uniftest, unifcheck)$p.value
  return(pvalsunif)
}
if (mean(testiter<0.05) < 0.1){
  print("The test of the Uniform Distribution passes.")
}else{
  print("The test of the Uniform Distribution fails.")
}
