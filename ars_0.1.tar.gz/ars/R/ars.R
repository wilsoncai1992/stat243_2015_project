library(devtools)
############# Renee's function of check.log.concave #############
check.log.concave <- function(abscissae.result){
  deriv.seq <- abscissae.result[,3]
  is.concave <- (deriv.seq[1] > 0) & (tail(deriv.seq, 1) < 0)
  #-----------------------------------------------------------------------------------------
  # in case of exponential, directly pass check
  hp_T <- abscissae.result[,3]
  names(hp_T) <- NULL
  if( all.equal(hp_T, rep(hp_T[1], length(hp_T))) == TRUE ) { is.concave <- TRUE }
  #-----------------------------------------------------------------------------------------
  return(is.concave)
}
#################################################################
#-----------------------------------------------------------------------------------------
# Fixed k points to create abscissae
gen.abscissae <- function(abscissae.grid, h, lb, ub){
  library(numDeriv)

  h.x <- h(abscissae.grid)
  h.deriv <- grad(func = h, x = abscissae.grid)
  abscissae.result <- cbind(abscissae.grid, h.x, h.deriv)
  #-----------------------------------------------------------------------------------------
  # in case of exponential, we can continue simulation by defining zi be the domain bounds
  hp_T <- abscissae.result[,3]
  # med <- median(1:length(hp_T))
  # to.pick <- c(ceiling(med - 0.5), ceiling(med + 0.5))
  # to.pick <- c(1, length(hp_T))
  # if( all.equal(hp_T, rep(hp_T[1], length(hp_T))) == TRUE ) { abscissae.result <- abscissae.result[to.pick,] }
  if( all.equal(hp_T, rep(hp_T[1], length(hp_T))) == TRUE ) {
    abscissae.grid <- c(lb + 1e-3, ub - 1e-3)
    h.x <- h(abscissae.grid)
    h.deriv <- grad(func = h, x = abscissae.grid)
    abscissae.result <- cbind(abscissae.grid, h.x, h.deriv)
  }
  #-----------------------------------------------------------------------------------------
  return(abscissae.result)
}
#-----------------------------------------------------------------------------------------
# # Integate over exponentiated upper envelope

# Compute the norm.constant.
# compute_norm_constant = function(abscissae.result, z){
#   all.mass <- sum(
#     rep(c(-1, 1), length(abscissae.result[,3])) *
#       rep(1/abscissae.result[,3], each = 2) *
#       exp(rep(abscissae.result[,2], each = 2) +
#             rep(abscissae.result[,3], each = 2) *
#             (c(-Inf, rep(z, each = 2), Inf) - rep(abscissae.result[,1], each = 2)))
#   )
#   # Normalize total density such that sum to 1
#   norm.constant <- -log(all.mass)
#   return(norm.constant)
# }

compute_norm_constant = function(abscissae.result,z, lb, ub){
  if(is.infinite(lb) & is.infinite(ub)){
    all.mass <- sum(
      rep(c(-1, 1), length(abscissae.result[,3])) *
        rep(1/abscissae.result[,3], each = 2) *
        exp(rep(abscissae.result[,2], each = 2) +
              rep(abscissae.result[,3], each = 2) *
              (c(-Inf, rep(z, each = 2), Inf) - rep(abscissae.result[,1], each = 2)))
    )
  }else{
    all.mass <- sum(
      rep(c(-1, 1), length(abscissae.result[,3])) *
        rep(1/abscissae.result[,3], each = 2) *
        exp(rep(abscissae.result[,2], each = 2) +
              rep(abscissae.result[,3], each = 2) *
              (c(lb, rep(z, each = 2), ub) - rep(abscissae.result[,1], each = 2)))
    )
  }
  # Normalize total density such that sum to 1
  norm.constant <- -log(all.mass)
  return(norm.constant)
}

# Compute z.
compute_z = function(abscissae.result){
  diff.h <- diff(abscissae.result[,2])
  xh.deriv <- abscissae.result[,1] * abscissae.result[,3]
  diff.xh.deriv <- diff(xh.deriv)
  diff.h.deriv <- diff(abscissae.result[,3])
  z <- (diff.h - diff.xh.deriv)/ (-diff.h.deriv)
  return(z)
}




# UN-normaized version of upper envelope (not exponentiated)
du.unnormalized <- function(x, abscissae.result, z, lb, ub){
  j <- sapply(x, function(it) min(which(it <= c(z, ub))))
  dens.u <- abscissae.result[j, 2] + (x - abscissae.result[j, 1]) * abscissae.result[j, 3]
  return(dens.u)
}

# Normaized version of upper envelope (not exponentiated).
du.normalized <- function(x, abscissae.result, z, norm.constant, lb, ub){
  j <- sapply(x, function(it) min(which(it <= c(z, ub))))
  dens.u <- abscissae.result[j, 2] + (x - abscissae.result[j, 1]) * abscissae.result[j, 3] + norm.constant
  return(dens.u)
}


#-----------------------------------------------------------------------------------------
# Inverse sampling of upper enelope density
#-----------------------------------------------------------------------------------------
# Inverse cdf of S
S_inv <- function(cdf, abscissae.result, z, norm.constant, lb, ub){
  cdf.z <- matrix(rep(c(-1, 1), length(abscissae.result[,3])) *
                    rep(1/abscissae.result[,3], each = 2) *
                    exp(rep(abscissae.result[,2], each = 2) +
                          rep(abscissae.result[,3], each = 2) *
                          (c(lb, rep(z, each = 2), ub) - rep(abscissae.result[,1], each = 2)) +norm.constant),
                  byrow = TRUE, ncol = 2)
  mass.grid <- rowSums(cdf.z)

  cum.mass <- cumsum(mass.grid)
  j <- sapply(cdf, function(it) min(which(it <= cum.mass)))

  delta.mass <- matrix(nrow = length(j), ncol = 1)
  x.hat <- matrix(nrow = length(j), ncol = 1)

  z.grid <- c(z, ub)


  if(is.infinite(lb) & is.infinite(ub)){
    delta.mass[j==1] <- cdf[j==1]
    x.hat[j==1] <- (log(abscissae.result[1,3] * delta.mass[j==1]) - abscissae.result[1,2] - norm.constant)/abscissae.result[1,3] + abscissae.result[1,1]

    j.nonzero <- j[j!=1]
    delta.mass[j!=1] <- cdf[j!=1] - cum.mass[j.nonzero - 1]#[j.nonzero - 1]
    partial.formula <- exp(abscissae.result[j.nonzero,2] + abscissae.result[j.nonzero,3] * (z.grid[j.nonzero - 1] - abscissae.result[j.nonzero,1]) + norm.constant) + delta.mass[j!=1] * abscissae.result[j.nonzero,3]
    x.hat[j!=1] <- (log(partial.formula) - abscissae.result[j.nonzero,2] - norm.constant) / abscissae.result[j.nonzero,3] + abscissae.result[j.nonzero,1]

    j.last <- j[j==length(cum.mass)]
    # x.hat[j==length(cum.mass)] <- (log(abscissae.result[j.last,3] * (delta.mass[j==length(cum.mass)] - tail(mass.grid, 1))) - abscissae.result[j.last,2] - norm.constant)/abscissae.result[j.last,3] + abscissae.result[j.last,1]
    x.hat[j==length(cum.mass)] <- (log(abscissae.result[j.last,3] * (cdf[j==length(cum.mass)] - 1.0)*as.integer((cdf[j==length(cum.mass)] - 1.0) <= 0)) - abscissae.result[j.last,2] - norm.constant)/abscissae.result[j.last,3] + abscissae.result[j.last,1]
  }else{
    delta.mass[j==1] <- cdf[j==1]
    x.hat[j==1] <- (log(abscissae.result[1,3] * (delta.mass[j==1] - cdf.z[1,1])) - abscissae.result[1,2] - norm.constant)/abscissae.result[1,3] + abscissae.result[1,1]
    x.hat[j==1][x.hat[j==1] < lb] <- lb

    j.nonzero <- j[j!=1]
    delta.mass[j!=1] <- cdf[j!=1] - cum.mass[j.nonzero - 1]#[j.nonzero - 1]
    partial.formula <- exp(abscissae.result[j.nonzero,2] + abscissae.result[j.nonzero,3] * (z.grid[j.nonzero - 1] - abscissae.result[j.nonzero,1]) + norm.constant) + delta.mass[j!=1] * abscissae.result[j.nonzero,3]
    x.hat[j!=1] <- (log(partial.formula) - abscissae.result[j.nonzero,2] - norm.constant) / abscissae.result[j.nonzero,3] + abscissae.result[j.nonzero,1]

    j.last <- j[j==length(cum.mass)]
    # x.hat[j==length(cum.mass)] <- (log(abscissae.result[j.last,3] * (delta.mass[j==length(cum.mass)] - tail(mass.grid, 1))) - abscissae.result[j.last,2] - norm.constant)/abscissae.result[j.last,3] + abscissae.result[j.last,1]
    x.hat[j==length(cum.mass)] <- (log(abscissae.result[j.last,3] * (cdf[j==length(cum.mass)] - 1.0 + tail(as.vector(cdf.z),1))*as.integer((cdf[j==length(cum.mass)] - 1.0) <= 0)) - abscissae.result[j.last,2] - norm.constant)/abscissae.result[j.last,3] + abscissae.result[j.last,1]
  }






  return(x.hat)
}


# Inverse sampling function
rs <- function(n.sim, S_inv, abscissae.result, z, norm.constant, lb, ub){
  u.temp <- runif(n = n.sim)
  x.temp <- S_inv(u.temp, abscissae.result, z, norm.constant, lb, ub)
  return(x.temp)
}


#-------------------------------------------------------------------------------------------

#----------------------------------------------
#This function runs a binary search to find the chord we should use
#to represent this point within the lower function.

binary <- function(Tk, sampledPoint){
  bot <- 1
  top <- (length(Tk))
  for(k in 1:(log2(length(Tk)))){
    q <- Tk[(bot+(top-bot)/2)]
    if(sampledPoint > q){
      bot <- (bot+(top-bot)/2)
    }else{
      top <- (bot+(top-bot)/2)}
  }
  index <- floor(((top+bot)/2))
  return(index)
}
#-------------------------------------------------
#This function runs the 'l' function.
lowerbound <- function(x, coefficients, index){
  lvalue <- coefficients[index,1]*x + coefficients[index,2]
  return(lvalue)
}
#-------------------------------------------------
# This function updates the chords of the 'l' function with new Tk points.
# The inputs are (sorted) Tk and the values of h at points of Tk respectively,
# represented as two vectors.
lupdater <- function(Tk,h_Tk){
  k=length(Tk)
  coefficients <- matrix(c((h_Tk[1:(k-1)]-h_Tk[2:k])/(Tk[1:(k-1)]-Tk[2:k])), k-1, 2, byrow = FALSE)
  coefficients[,2] = h_Tk[1:(k-1)] - coefficients[,1]*Tk[1:(k-1)]
  return(coefficients)
}


# This function performs the updating step.
# The inputs are original_abs, which is a matrix of dimension k times 3, storing x,h,h'..
# and the original coefficients matrix.
# and the point to be added, x_star, and h_star=h(x_star), h_p_star = h'(x_star).
# The outputs are the coordinates and derivative of abscissae with a new point added, as a matrix with three columns, each recording x_coord, y_coord and derivatives.
update <- function(original_abs,x_star,h_star,h_deri_star){
  #-----------------------------------------------------------------------------------------
  # in case of exponential, directly not update
  hp_T <- original_abs[,3]
  names(hp_T) <- NULL
  if( all.equal(hp_T, rep(hp_T[1], length(hp_T))) == TRUE ) {
    updated_abs <- original_abs
  }else{
    #-----------------------------------------------------------------------------------------
    # Represent the information about x_star as a vector.
    added_abs = cbind(x_star,h_star,h_deri_star)
    # Add the new point to the original abscissae.
    updated_abs = rbind(added_abs,original_abs)
    # Sort by the x coordinates in ascending order.
    updated_abs = updated_abs[order(updated_abs[,1]),]
  }
  return(updated_abs)
}

# This function updates the coefficient matrix.
update_coeff <- function(coefficients,x_star,updated_abscissae.result){
  #-----------------------------------------------------------------------------------------
  # in case of exponential, directly not update
  hp_T <- updated_abscissae.result[,3]
  names(hp_T) <- NULL
  if( all.equal(hp_T, rep(hp_T[1], length(hp_T))) == TRUE ) {
    updated_coefficients <- coefficients
  }else{
    #-----------------------------------------------------------------------------------------
    # The index of the added point:
    Tk = updated_abscissae.result[,1]
    h_Tk = updated_abscissae.result[,2]
    i_added = which(Tk == x_star)
    h_star = h_Tk[i_added]

    # Update the coefficient matrix.
    if(i_added<length(Tk) && i_added>1){
      #     coefficients[i_added-1,1] <- (h_Tk[i_added-1]-h_Tk[i_added]) / (Tk[i_added-1]-Tk[i_added])
      #     coefficients[i_added-1,2] <- h_Tk[i_added-1] - coefficients[i_added-1,1] * Tk[i_added-1]
      #     new_x = (h_star-h_Tk[i_added+1]) / (x_star-Tk[i_added+1])
      #     new_row = c(new_x,h_star-new_x*x_star)
      # updated_coefficients = rbind(coefficients[1:(i_added-1),],new_row,
      # coefficients[i_added:length(coefficients[,1]),])
      new_x = (h_star-h_Tk[i_added+1]) / (x_star-Tk[i_added+1])
      new_row = c(new_x,h_star-new_x*x_star)
      if(i_added<=length(coefficients[,1])){
        updated_coefficients = rbind(coefficients[1:(i_added-1),],new_row,
                                     coefficients[i_added:length(coefficients[,1]),])
      }else{
        updated_coefficients = rbind(coefficients[1:(i_added-1),],new_row)
      }
      updated_coefficients[i_added-1,1] <- (h_Tk[i_added-1]-h_Tk[i_added]) / (Tk[i_added-1]-Tk[i_added])
      updated_coefficients[i_added-1,2] <- h_Tk[i_added-1] - updated_coefficients[i_added-1,1] * Tk[i_added-1]

      #     updated_coefficients = rbind(coefficients[1:(i_added-2),],new_row,
      #                                  coefficients[(i_added-1):length(coefficients[,1]),])

    }

    if(i_added == 1){
      new_x = (h_star-h_Tk[i_added+1]) / (x_star-Tk[i_added+1])
      new_column = c(new_x,h_star-new_x*x_star)
      updated_coefficients = rbind(new_column, coefficients)
    }
    if(i_added == length(Tk)){
      new_x = (h_star-h_Tk[length(h_Tk)-1]) / (x_star-Tk[length(Tk)-1])
      new_column = c(new_x,h_star-new_x*x_star)
      updated_coefficients = rbind(coefficients,new_column)
    }
  }
  return(updated_coefficients)
}

library(roxygen2)
#' Adaptive Rejection Sampling
#'
#' A method for rejection sampling from any univariate log-concave probability density function. The method is adaptive: as sampling proceeds, the rejection
#' envelope and the squeezing function converge to the density function. The rejection envelope and squeezing function are piecewise exponential functions, the
#' rejection envelope touching the density at previously sampled points, and the squeezing function forming arcs between those points of contact. The technique
#' is intended for situations where evaluations of the density is computationally expensive, in particualr for applications of Gibbs sampling to Bayesian models
#' with non-conjugacy.
#'
#' @param n Total number of points to be sampled using ARS
#' @param f The density function to be sampled from, it has to be an object from class "expression" or "function"
#' @param h Log of the density
#' @param k The number of initial points
#' @param domain  A vector of the Lower bound (lb) and the Upper bound (up) of the function f
#' @return The ars function returns a vector with the n simulated values from f.
#' @export
#---------------------------------------------
#This is the main engine.  It takes the log of a function (h), a required number of
#values (n), and the number of points in the initial abscissae(k).
ars243 <- function(n, f = NULL, h = NULL, k, domain = c(-Inf, Inf)){

  #-----------------------------------------------------------------------------------------
  # Checking input validity
  #-----------------------------------------------------------------------------------------
  M <- n/100
  if(is.null(f) & is.null(h)){
    stop('"f" and "h" are both missing. No default value.')
  }else{
    if(!is.null(f)){
      if ( is.expression(f) ) {
        f_exp <- f
        f <- function(x) { eval(f_exp) }
      }
      if (!is.function(f)) {
        stop( '"f" has to be either expr or function' )
      }
    }
  }
  if(k < 4){
    k <- 4
  }

  if(is.null(h)){
    h <- function(x){
      return(log(f(x)))
    }
  }

  lb <- domain[1]
  ub <- domain[2]
  #-----------------------------------------------------------------------------------------
  # Main body
  #-----------------------------------------------------------------------------------------
  ## 'finalValues' will be what we return.  We initiate it empty.
  finalValues <- c()
  if (all.equal(domain, c(-Inf, Inf)) == TRUE){
    abscissae.grid <- seq(-5, 5, length.out = k)
  }else{
    abscissae.grid <- seq(lb, ub, length.out = k + 2)
    abscissae.grid <- abscissae.grid[abscissae.grid > lb & abscissae.grid < ub]
  }

  abscissae.result <- gen.abscissae(abscissae.grid, h, lb, ub)
  #-----------------------------------------------------------------------------------------
  # If uniform
  if(all(abscissae.result[,3] == 0)){
    finalValues <- runif(n, min = lb, max = ub)
    #-----------------------------------------------------------------------------------------
  }else{
    #-----------------------------------------------------------------------------------------
    # Remove points where derivative is zero
    if(sum(abscissae.result[,3] == 0) > 0){
      abscissae.result <- abscissae.result[abscissae.result[,3] != 0,]
    }
    #-----------------------------------------------------------------------------------------
    ############# Renee's function of check.log.concave #############
    if(check.log.concave(abscissae.result) == FALSE){
      # expand the grid
      abscissae.grid <- seq(lb, ub, length.out = 2 * k)
      abscissae.grid <- abscissae.grid[abscissae.grid > lb & abscissae.grid < ub]
      abscissae.result <- gen.abscissae(abscissae.grid, h, lb, ub)

      if(check.log.concave(abscissae.result) == FALSE){
        # If still not log concave
        stop("f is not log-concave! Or k is too small.")
      }
    }

    while(length(finalValues) < n){
      Tk = abscissae.result[,1]
      h_Tk = abscissae.result[,2]
      coefficients <- lupdater(Tk,h_Tk)
      #Take a random point from the 'sk' function, known as 'rs'.
      z = compute_z(abscissae.result)
      norm.constant = compute_norm_constant(abscissae.result,z, lb, ub)
      # Wilson
      sampler <- as.vector(rs(M, S_inv, abscissae.result, z, norm.constant, lb, ub))
      #If that point lies outside the bounds set by my Tk values
      condition1 =  (sampler < Tk[1] | sampler > Tk[length(Tk)])
      sampler_rejected_in_1 = sampler[condition1]
      sampler_accepted_in_1 = sampler[condition1 == FALSE]
      #The value of the lower bound is calculated from this chord, found with binary.
      lval <- sapply(sampler_accepted_in_1, function(sampler) lowerbound(sampler,coefficients,binary(Tk, sampler)))
      #The value of the upper bound is calculated by Wilson.
      uval <- sapply(sampler_accepted_in_1, function(x) du.unnormalized(x, abscissae.result, z, lb, ub))
      uniform = runif(length(sampler_accepted_in_1))

      condition2 = (uniform <= exp(lval - uval))
      sampler_rejected_in_2 = sampler_accepted_in_1[condition2 == FALSE]
      sampler_accepted_in_2 = sampler_accepted_in_1[condition2]
      uniform_rejected_in_2 = uniform[condition2 == FALSE]
      uval_rejected_in_2 = uval[condition2 == FALSE]
      # Phase 2
      sampler_rejected_in_phase_1 = c(sampler_rejected_in_1,sampler_rejected_in_2)
      h_rejected_in_phase_1 = h(sampler_rejected_in_phase_1)
      h.deriv <- grad(func = h, x = sampler_rejected_in_phase_1)
      uniform_in_phase_2 = c(runif(length(sampler_rejected_in_1)),uniform_rejected_in_2)
      if(length(sampler_rejected_in_1)!=0){
        uval = c(sapply(sampler_rejected_in_1, function(x) du.unnormalized(x, abscissae.result, z, lb, ub)),
                 uval_rejected_in_2)

      }else{
        uval = uval_rejected_in_2
      }
      if(length(uval!=0)){
        condition2 = (uniform_in_phase_2 < exp(h_rejected_in_phase_1-uval))
        sampler_accepted_in_phase_2 = sampler_rejected_in_phase_1[condition2]
      }else{
        sampler_accepted_in_phase_2=c()
      }
      # Add accepted samples.
      finalValues=c(finalValues,sampler_accepted_in_1,sampler_accepted_in_phase_2)
      abscissae.result = update(abscissae.result,sampler_rejected_in_phase_1,h_rejected_in_phase_1,h.deriv)

      if(check.log.concave(abscissae.result) == FALSE){
        stop("f is not log-concave!")
      }
    }
    #I was printing the length of Tk to see how many points I updated with (typically
    #it ends up being 15-30).
    print(paste('Total number of abscissae grid point:', length(Tk)) )
  }
  return(finalValues)
}
